package slp;

public class Formal {
	public final String type;
	public final String id;
	public int line;
	public Formal(String type, String id, int line){
		this.type = type;
		this.id = id;
		this.line = line;
	}
}
